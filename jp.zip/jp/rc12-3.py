# Открываем исходный файл для чтения
with open("translit.txt", "r", encoding='utf-8') as f:
    # Читаем все слова из файла
    words = f.read().split()

# Открываем целевой файл для записи
with open("targ.txt", "w", encoding='utf-8') as f:
    for word in words:
        if len(word) <= 14:
            # Если слово короче или равно 14 символов, записываем его в файл без изменений
            f.write(word + "\n")
        else:
            # Если слово длиннее 14 символов, разбиваем его на подстроки по 8 символов
            split_words = [word[i:i+14] for i in range(0, len(word), 8)]
            # Записываем все подстроки в файл, каждую на отдельной строке, но только если строка не пустая
            for split_word in split_words:
                if split_word != "":
                    f.write(split_word + "\n")
