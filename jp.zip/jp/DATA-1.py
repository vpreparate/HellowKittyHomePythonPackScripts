import chardet

# Открываем файл с текстом для чтения
with open('data.txt', 'rb') as file:
    rawdata = file.read()
    result = chardet.detect(rawdata)
    encoding = result['encoding'] if result['encoding'] is not None else 'utf-8'
    text = rawdata.decode(encoding)
    words = text.split()
    with open('sym.txt', 'a', encoding='utf-8') as l:
        for word in words:
            l.write(word + '\n')
