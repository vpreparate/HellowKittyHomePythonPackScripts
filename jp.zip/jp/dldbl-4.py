with open("targ.txt", "r", encoding='utf-8') as input_file, open("output.txt", "w", encoding='utf-8') as output_file:
    unique_lines = set(input_file.readlines())
    output_file.writelines(sorted(unique_lines))
