import os  #импорт библиотеки для взаимодействия с операционной системой
import random  #импорт библиотеки для генерации случайных чисел
#импорт нескольких классов из библиотеки aiogram
from aiogram import Bot, Dispatcher, types
#импорт класса InputFile из библиотеки aiogram
from aiogram.types import InputFile
#импорт функции executor из библиотеки aiogram
from aiogram import executor
#импорт переменной TOKEN из файла config
from config import TOKEN
#импорт библиотеки для организации асинхронного программирования
import asyncio

# Укажите путь к папке с песнями
songs_folder = 'oMRandom2017'
#создание экземпляра класса Bot с аргументом token=TOKEN
bot = Bot(token=TOKEN)
#создание экземпляра класса Dispatcher с аргументом bot
dp = Dispatcher(bot)
#создание пустого словаря button_clicks
button_clicks = {}

#декоратор для обработчика команды /start
@dp.message_handler(commands=['start'])
#асинхронная функция start с аргументом message
async def start(message: types.Message):
    #создание клавиатуры с двумя кнопками
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    #создание кнопки "Получить кат"
    button = types.KeyboardButton("Полyчить кат")
    #создание кнопки "Отправить песню"
    button2 = types.KeyboardButton("Отправить песню")
    #присваивание переменной userid значения id пользователя
    userid = int(message.from_user.id)
    #присваивание переменной username значения имени пользователя
    username = str(message.from_user.username)
    #вывод сообщения о подключении пользователя к боту
    print(f"ID {userid} с ником {username} авторизовался в Боте")
    #добавление кнопок на клавиатуру
    keyboard.add(button, button2)
    #отправка сообщения пользователю
    await message.answer("Привет! Нажми на кнопку, чтобы получить случaйный кат.", reply_markup=keyboard)
#определение асинхронной функции is_user_member с аргументами chat_id и user_id и возвращаемым значением bool
async def is_user_member(chat_id: int, user_id: int) -> bool:
    #присваивание переменной chat_member значения результата выполнения метода get_chat_member
    #с аргументами chat_id и user_id
    chat_member = await bot.get_chat_member(chat_id, user_id)
    #возврат результата проверки статуса пользователя
    return chat_member.status in (types.ChatMemberStatus.CREATOR, types.ChatMemberStatus.ADMINISTRATOR, types.ChatMemberStatus.MEMBER)

@dp.message_handler(lambda message: message.text == "Полyчить кат")
async def send_random_song(message: types.Message):
    userid = int(message.from_user.id)
    #проверка на членство - вызов ф-ции прописаной выше
    if await is_user_member('@YMBAND', message.from_user.id):
        #если пользователь не нажимал кнопку то присвается одно нажатие
        if userid not in button_clicks:
            button_clicks[userid] = 1
            await message.answer("Вам достyпно 5 катов в день")
        else: # если нажимал прибавляется +1 нажатие
            button_clicks[userid] += 1
        if button_clicks[userid] <= 5: # кат отправляется только пять раз
           song_file = random.choice([f for f in os.listdir(songs_folder) if f.endswith('.mp3')])
           with open(os.path.join(songs_folder, song_file), 'rb') as audio:
               await bot.send_audio(message.chat.id, audio, title=song_file)
    #если нажатие кнопки не участника сообщества то кат отправялется только один раз
    else:
        if userid not in button_clicks:
            button_clicks[userid] = 1
        else:
            button_clicks[userid] += 1
        if button_clicks[userid] <= 1:
           song_file = random.choice([f for f in os.listdir(songs_folder) if f.endswith('.mp3')])
           await message.answer("Для тех кто не встyпил в грyппy @YMBAND достyпен только 1 кат в день")
           with open(os.path.join(songs_folder, song_file), 'rb') as audio:
               await bot.send_audio(message.chat.id, audio, title=song_file)

@dp.message_handler(lambda message: message.text == "Отправить песню")
async def save_file(message: types.Message):
    await message.answer("Пожалуйста, отправьте песню.")
@dp.message_handler(content_types=["audio"])
async def download(message: types.Message):
    file_id = message.audio.file_id
    file_info = await bot.get_file(file_id)
    file_path = file_info.file_path
    # если нужно указать нужную директорию для загружаемых песен в данном случае это oMRandom2017 
    #file_name = "oMRandom2017/" + message.audio.file_name  
    file_name = message.audio.file_name
    await bot.download_file(file_path, file_name)


    await message.answer("Песня отправленна!!!")

# Функция для обнуления счетчика каждые 12 часов
async def reset_button_clicks():
    while True:
        await asyncio.sleep(43200)  # Подождать 12 часов
        button_clicks.clear()  # Обнулить счетчик


if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.create_task(reset_button_clicks())
    executor.start_polling(dp, skip_updates=True)
