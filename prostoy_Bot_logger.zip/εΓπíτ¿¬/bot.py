import random
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from api_token import token

WORDS_FILE = "words.txt"
PHRASES_FILE = "phrases.txt"

bot = Bot(token)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)


#Эта строка указывает, что следующая функция будет обрабатывать сообщения, начинающиеся с команды "/start".
@dp.message_handler(commands=["start"])
# Эта функция приветствует пользователя и рассказывает о возможностях бота.
async def start(message: types.Message):
    await message.reply("Привет! Я бот, который может выдавать случайные слова и фразы.")

#Эта строка указывает, что следующая функция будет обрабатывать сообщения, начинающиеся с команды "/word".
@dp.message_handler(commands=["word"])
# Эта функция открывает файл со словами, выбирает случайное слово из файла
#и отправляет его в качестве ответа пользователю.
async def random_word(message: types.Message):
    with open(WORDS_FILE, "r") as file:
        all_words = file.readlines()
        random.shuffle(all_words)
        selected_word = random.choice(all_words).strip()
    await message.reply(selected_word)
# Эта строка указывает, что следующая функция будет обрабатывать сообщения, начинающиеся с команды "/ph".
@dp.message_handler(commands=["ph"])
#Эта функция открывает файл с фразами,
#выбирает случайную фразу из файла и отправляет её в качестве ответа пользователю.
async def random_phrase(message: types.Message):
    with open(PHRASES_FILE, "r") as file:
        all_phrases = file.readlines()
        random.shuffle(all_phrases)
        selected_phrase = random.choice(all_phrases).strip()
    await message.reply(selected_phrase)

# Эта строка указывает, что следующая функция будет обрабатывать любые сообщения, не являющиеся командами.
@dp.message_handler()
#Эта функция разделяет текст сообщения на слова и сохраняет их в файлы со словами и фразами.
async def save_words_and_phrases(message: types.Message):
    words_and_phrases = message.text.split()
    with open(WORDS_FILE, "a") as words_file:
        for word in words_and_phrases:
           words_file.write(word + "\n")
    with open(PHRASES_FILE, "a") as phrases_file:
        phrases_file.write(" ".join(words_and_phrases))
        phrases_file.write("\n")

# Здесь происходит запуск бота через библиотеку aiogram.
if __name__ == '__main__':
    from aiogram import executor
    executor.start_polling(dp)
